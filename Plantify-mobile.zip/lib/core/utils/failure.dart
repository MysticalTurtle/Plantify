class Failure {
  final String message;
  final bool isBackend;
  Failure({required this.message, required this.isBackend});
}