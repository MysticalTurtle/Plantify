class Server {
  // static String base = "http://192.168.3.9:3030/api/";
  static String base = "https://plantify-monorepo.up.railway.app/api/";
}