import 'package:flutter/material.dart';

class RecordItem extends StatelessWidget {
  const RecordItem({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      
    );
  }
}
