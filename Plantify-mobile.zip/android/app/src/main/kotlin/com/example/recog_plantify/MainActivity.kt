package com.example.recog_plantify

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
