# RecogPlantify
 App to recognize plants and their characteristics. It is developed to inform people about their benefits.
 It was made with clean architecture following the SOLIS principles

 Github Repository: https://github.com/MysticalTurtle/Plantify
 Author: Edson Daniel Salvador Soel

 Architecture:
 We have 4 main folers: core, domain, data and presentation.
 Initially using clean architecture.

 Core:
 Here we have general configuration for the project such as routes, constants, Failure base class and utils

 Domain:
 Here we have the entities for the projects, the entities are 

 Data:

 Presentation:
 The project is using cubit for state management

